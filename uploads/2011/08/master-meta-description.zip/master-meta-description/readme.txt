=== Simple Meta Description ===
Contributor: Dejan Batanjac
Donate link: http://programming-review.com/
Tags: meta, description, seo
Requires at least: 3.0
Tested up to: 3.1
Stable tag: 1.0

Creates meta description write panel for posts and pages.

== Description ==

Creates meta description write panel for posts and pages. Meta description write panels are not present in the default WordPress installation.

== Installation ==

1. Upload `master-meta-description`  folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.0 =

Initial version
