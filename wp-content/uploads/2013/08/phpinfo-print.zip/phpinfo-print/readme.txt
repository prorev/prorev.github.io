=== phpinfo-print ===
Contributors: Dejan Batanjac
Donate link: http://programming-review.com/
Tags: phpinfo, hosting data, webserver, settings
Requires at least: 3.0
Tested up to: 3.6
Stable tag: 1.0

Displays web server information in a traditional way just like phpinfo() function

== Description ==
Simple WordPress plugin that displays exactly the same info as phpinfo() function and nothing more, in the classic presentation (see the screenshots).
Basically the smallest peace of code you can imagine.

== Installation ==

1. Upload `phpinfo`  folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress


== Screenshots ==

1. Exact phpinfo() information.
2. Exact CSS styles.
3. Exact look.

== Changelog ==

= 1.1 =

Initial version
